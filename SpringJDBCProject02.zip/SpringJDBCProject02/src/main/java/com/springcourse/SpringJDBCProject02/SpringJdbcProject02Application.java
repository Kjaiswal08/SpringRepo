package com.springcourse.SpringJDBCProject02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJdbcProject02Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringJdbcProject02Application.class, args);
	}

}
