package com.collegeproject.intrusiondetection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntrusiondetectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntrusiondetectionApplication.class, args);
	}

}
